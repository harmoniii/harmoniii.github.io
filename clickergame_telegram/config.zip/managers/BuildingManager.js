import { CleanupMixin } from '../core/CleanupManager.js';
import { eventBus, GameEvents } from '../core/GameEvents.js';
import { GAME_CONSTANTS } from '../config/GameConstants.js';
import { dataLoader } from '../utils/DataLoader.js';

export class BuildingManager extends CleanupMixin {
  constructor(gameState) {
    super();
    this.gameState = gameState;
    this.productionIntervals = new Map();
    
    // Данные строений загружаются асинхронно
    this.buildingDefs = [];
    this.buildingCategories = {};
    this.isDataLoaded = false;
    
    this.initializeBuildings();
    console.log('🏗️ BuildingManager initialized');
  }

  async initializeBuildings() {
    try {
      // Загружаем данные строений из внешнего файла
      await this.loadBuildingData();
      
      // Инициализируем строения в игровом состоянии
      this.setupGameStateBuildings();
      this.validateBuildings();
      this.startProduction();
      
      console.log(`✅ BuildingManager: Loaded ${this.buildingDefs.length} building definitions`);
    } catch (error) {
      console.error('❌ BuildingManager initialization failed:', error);
      // В случае ошибки используем резервные данные
      this.setupFallbackBuildings();
    }
  }

  async loadBuildingData() {
    try {
      const data = await dataLoader.loadBuildingsData();
      
      if (dataLoader.validateBuildingsData(data)) {
        this.buildingDefs = data.buildings;
        this.buildingCategories = data.categories;
        this.isDataLoaded = true;
        console.log('✅ Building data loaded and validated');
      } else {
        throw new Error('Building data validation failed');
      }
    } catch (error) {
      console.error('❌ Failed to load building data:', error);
      throw error;
    }
  }

  setupFallbackBuildings() {
    console.warn('⚠️ Using fallback building definitions');
    this.buildingDefs = [
      {
        id: 'sawmill',
        img: '🪚',
        name: 'Sawmill',
        description: 'Produces wood automatically',
        price: { wood: 0, stone: 10, iron: 5 },
        production: { resource: 'wood', amount: 1, interval: 10000 },
        maxLevel: 10,
        category: 'production'
      }
    ];
    this.buildingCategories = { production: '🏭 Production' };
    this.isDataLoaded = true;
    this.setupGameStateBuildings();
    this.startProduction();
  }

  setupGameStateBuildings() {
    if (!this.gameState.buildings) {
      this.gameState.buildings = {};
    }

    this.buildingDefs.forEach(def => {
      if (!this.gameState.buildings[def.id]) {
        this.gameState.buildings[def.id] = {
          level: 0,
          active: false
        };
      }
    });
  }

  validateBuildings() {
    Object.keys(this.gameState.buildings).forEach(buildingId => {
      const building = this.gameState.buildings[buildingId];
      const def = this.getBuildingDefinition(buildingId);
      
      if (!def) {
        delete this.gameState.buildings[buildingId];
        return;
      }

      building.level = Math.max(0, Math.min(
        Math.floor(building.level || 0),
        def.maxLevel
      ));
      building.active = Boolean(building.active && building.level > 0);
    });
  }

  getBuildingDefinition(buildingId) {
    return this.buildingDefs.find(def => def.id === buildingId);
  }

  canAfford(buildingId) {
    const def = this.getBuildingDefinition(buildingId);
    if (!def) return false;

    const building = this.gameState.buildings[buildingId];
    if (building.level >= def.maxLevel) return false;

    const price = this.calculatePrice(def.price, building.level);
    const finalPrice = this.applyBuildingDiscounts(price);
    return this.gameState.canAffordResources(finalPrice);
  }

  applyBuildingDiscounts(basePrice) {
    let finalPrice = { ...basePrice };
    
    if (this.gameState.tempBuildingDiscount && this.gameState.tempBuildingDiscount.uses > 0) {
      const discount = this.gameState.tempBuildingDiscount.discount;
      Object.keys(finalPrice).forEach(resource => {
        finalPrice[resource] = Math.max(1, Math.floor(finalPrice[resource] * (1 - discount)));
      });
    }
    
    return finalPrice;
  }

  calculatePrice(basePrice, level) {
    if (GAME_CONSTANTS.BUILDING_LINEAR_SCALING) {
      const linearMultiplier = 1 + (level * 0.5);
      const scaledPrice = {};
      Object.entries(basePrice).forEach(([resource, amount]) => {
        scaledPrice[resource] = Math.max(1, Math.floor(amount * linearMultiplier));
      });
      return scaledPrice;
    } else {
      const scalingFactor = Math.pow(1.5, level);
      const scaledPrice = {};
      Object.entries(basePrice).forEach(([resource, amount]) => {
        scaledPrice[resource] = Math.max(1, Math.floor(amount * scalingFactor));
      });
      return scaledPrice;
    }
  }

  buyBuilding(buildingId) {
    const def = this.getBuildingDefinition(buildingId);
    if (!def) {
      console.warn(`Unknown building: ${buildingId}`);
      return false;
    }

    const building = this.gameState.buildings[buildingId];
    if (building.level >= def.maxLevel) {
      console.warn(`Building ${buildingId} is already at max level`);
      return false;
    }

    const basePrice = this.calculatePrice(def.price, building.level);
    const finalPrice = this.applyBuildingDiscounts(basePrice);

    if (!this.gameState.spendResources(finalPrice)) {
      console.warn(`Cannot afford building ${buildingId}`);
      return false;
    }

    if (this.gameState.tempBuildingDiscount && this.gameState.tempBuildingDiscount.uses > 0) {
      this.gameState.tempBuildingDiscount.uses--;
      if (this.gameState.tempBuildingDiscount.uses <= 0) {
        delete this.gameState.tempBuildingDiscount;
      }
      eventBus.emit(GameEvents.NOTIFICATION, '📜 Ancient Blueprint used! Discount applied');
    }

    building.level++;
    building.active = true;

    if (building.level === 1) {
      this.startBuildingProduction(buildingId);
    }

    // Специальные эффекты для определенных строений
    if (buildingId === 'watchTower' && building.level === 1) {
      eventBus.emit(GameEvents.NOTIFICATION, '🗼 Watch Tower built! Raid system unlocked!');
      eventBus.emit('raid:system_unlocked', { buildingId, level: building.level });
    }

    eventBus.emit(GameEvents.BUILDING_BOUGHT, {
      buildingId,
      level: building.level,
      name: def.name
    });

    eventBus.emit(GameEvents.RESOURCE_CHANGED);
    console.log(`Building ${def.name} upgraded to level ${building.level}`);
    return true;
  }

  startProduction() {
    this.buildingDefs.forEach(def => {
      const building = this.gameState.buildings[def.id];
      if (building && building.level > 0 && building.active) {
        this.startBuildingProduction(def.id);
      }
    });
  }

  startBuildingProduction(buildingId) {
    const def = this.getBuildingDefinition(buildingId);
    if (!def) return;

    this.stopBuildingProduction(buildingId);

    const building = this.gameState.buildings[buildingId];
    if (!building.active || building.level <= 0) return;

    if (!def.production) return;

    const intervalId = this.createInterval(() => {
      this.produceBuildingResource(buildingId);
    }, def.production.interval, `building-${buildingId}`);

    this.productionIntervals.set(buildingId, intervalId);
    console.log(`Started production for ${def.name}`);
  }

  produceBuildingResource(buildingId) {
    const def = this.getBuildingDefinition(buildingId);
    const building = this.gameState.buildings[buildingId];
    
    if (!def || !building || !building.active) return;

    const production = def.production;
    if (!production) return;

    let amount;
    if (GAME_CONSTANTS.BUILDING_LINEAR_SCALING) {
      amount = production.amount * building.level;
    } else {
      amount = production.amount * building.level;
    }

    // Применяем бонусы
    if (this.gameState.buffs && this.gameState.buffs.includes('timeWarp')) {
      amount *= 2;
    }

    const abundanceBonus = this.getAbundanceBonus();
    if (abundanceBonus > 0) {
      amount *= (1 + abundanceBonus);
      console.log(`🌟 Abundance bonus: +${Math.floor(abundanceBonus * 100)}% to ${production.resource} production`);
    }

    this.gameState.addResource(production.resource, amount);

    // Специальные эффекты строений